

// This C++ file was created by SanEditor

#include "Atomic/obuComm/obuCommSAN.h"

#include <stdlib.h>
#include <iostream>

#include <math.h>


/*****************************************************************
                         obuCommSAN Constructor             
******************************************************************/


obuCommSAN::obuCommSAN(){


  TPRNetworkDelayGroup.initialize(2, "TPRNetworkDelayGroup");
  TPRNetworkDelayGroup.appendGroup((BaseGroupClass*) &TPRNetworkDelay_case1);
  TPRNetworkDelayGroup.appendGroup((BaseGroupClass*) &TPRNetworkDelay_case2);

  updateTPRGroup.initialize(2, "updateTPRGroup");
  updateTPRGroup.appendGroup((BaseGroupClass*) &updateTPR_case1);
  updateTPRGroup.appendGroup((BaseGroupClass*) &updateTPR_case2);

  MANetworkDelayGroup.initialize(2, "MANetworkDelayGroup");
  MANetworkDelayGroup.appendGroup((BaseGroupClass*) &MANetworkDelay_case1);
  MANetworkDelayGroup.appendGroup((BaseGroupClass*) &MANetworkDelay_case2);

  Activity* InitialActionList[10]={
    &assigningID, //0
    &trainExits, //1
    &trainArrival, //2
    &updatePosition, //3
    &TPRNetworkDelay_case1, //4
    &TPRNetworkDelay_case2, //5
    &updateTPR_case1, //6
    &updateTPR_case2, //7
    &MANetworkDelay_case1, //8
    &MANetworkDelay_case2  // 9
  };

  BaseGroupClass* InitialGroupList[7]={
    (BaseGroupClass*) &(trainArrival), 
    (BaseGroupClass*) &(updatePosition), 
    (BaseGroupClass*) &(TPRNetworkDelayGroup), 
    (BaseGroupClass*) &(updateTPRGroup), 
    (BaseGroupClass*) &(MANetworkDelayGroup), 
    (BaseGroupClass*) &(assigningID), 
    (BaseGroupClass*) &(trainExits)
  };

  trainID = new Place("trainID" ,0);
  Start = new Place("Start" ,1);
  Count = new Place("Count" ,nTrains);
  waitForEntering = new Place("waitForEntering" ,0);
  trainMovement = new Place("trainMovement" ,0);
  sendTPR = new Place("sendTPR" ,0);
  TPRtoRBC = new Place("TPRtoRBC" ,0);
  MAtoRBC = new Place("MAtoRBC" ,0);
  TPRwaiting = new Place("TPRwaiting" ,0);
  trainHasToExit = new Place("trainHasToExit" ,0);
  short temp_arrivalTimeshortArrayOfTrainsvalue = 0;
  arrivalTime = new shortArrayOfTrains("arrivalTime",temp_arrivalTimeshortArrayOfTrainsvalue);
  int temp_trainHeadPositionsintArrayOfTrainsvalue = 0;
  trainHeadPositions = new intArrayOfTrains("trainHeadPositions",temp_trainHeadPositionsintArrayOfTrainsvalue);
  int temp_trainTailPositionsintArrayOfTrainsvalue = 0;
  trainTailPositions = new intArrayOfTrains("trainTailPositions",temp_trainTailPositionsintArrayOfTrainsvalue);
  short temp_trainSpeedsshortArrayOfTrainsvalue = 0;
  trainSpeeds = new shortArrayOfTrains("trainSpeeds",temp_trainSpeedsshortArrayOfTrainsvalue);
  tprMsg_state temp_TPRmessagestprMsgArrayOfTrainsvalue = {0,0,0,0};
  TPRmessages = new tprMsgArrayOfTrains("TPRmessages",temp_TPRmessagestprMsgArrayOfTrainsvalue);
  int temp_trainMAsintArrayOfTrainsvalue = 0;
  trainMAs = new intArrayOfTrains("trainMAs",temp_trainMAsintArrayOfTrainsvalue);
  tprMsg_state temp_TPRmsgtprMsg = {0,0,0,0};
  TPRmsg = new tprMsg("TPRmsg",temp_TPRmsgtprMsg);
  maMsg_state temp_MAmessagesmaMsgOfTrainsvalue = {0,0};
  MAmessages = new maMsgOfTrains("MAmessages",temp_MAmessagesmaMsgOfTrainsvalue);
  BaseStateVariableClass* InitialPlaces[18]={
    trainID,  // 0
    Start,  // 1
    Count,  // 2
    waitForEntering,  // 3
    trainMovement,  // 4
    sendTPR,  // 5
    TPRtoRBC,  // 6
    MAtoRBC,  // 7
    TPRwaiting,  // 8
    trainHasToExit,  // 9
    arrivalTime,  // 10
    trainHeadPositions,  // 11
    trainTailPositions,  // 12
    trainSpeeds,  // 13
    TPRmessages,  // 14
    trainMAs,  // 15
    TPRmsg,  // 16
    MAmessages   // 17
  };
  BaseStateVariableClass* InitialROPlaces[0]={
  };
  initializeSANModelNow("obuComm", 18, InitialPlaces, 
                        0, InitialROPlaces, 
                        10, InitialActionList, 7, InitialGroupList);


  assignPlacesToActivitiesInst();
  assignPlacesToActivitiesTimed();

  int AffectArcs[47][2]={ 
    {1,0}, {3,0}, {8,0}, {0,0}, {2,0}, {9,1}, {4,1}, {3,2}, {4,2}, 
    {0,2}, {11,2}, {12,2}, {15,2}, {13,2}, {4,3}, {0,3}, {9,3}, 
    {11,3}, {13,3}, {12,3}, {15,3}, {5,4}, {6,4}, {0,4}, {16,4}, 
    {14,4}, {5,5}, {16,5}, {8,6}, {5,6}, {16,6}, {0,6}, {11,6}, 
    {13,6}, {8,7}, {5,7}, {16,7}, {0,7}, {11,7}, {13,7}, {7,8}, 
    {0,8}, {15,8}, {17,8}, {7,9}, {0,9}, {17,9}
  };
  for(int n=0;n<47;n++) {
    AddAffectArc(InitialPlaces[AffectArcs[n][0]],
                 InitialActionList[AffectArcs[n][1]]);
  }
  int EnableArcs[15][2]={ 
    {1,0}, {9,1}, {4,1}, {3,2}, {4,3}, {5,4}, {5,5}, {8,6}, {8,7}, 
    {7,8}, {0,8}, {17,8}, {7,9}, {0,9}, {17,9}
  };
  for(int n=0;n<15;n++) {
    AddEnableArc(InitialPlaces[EnableArcs[n][0]],
                 InitialActionList[EnableArcs[n][1]]);
  }

  for(int n=0;n<10;n++) {
    InitialActionList[n]->LinkVariables();
  }
  CustomInitialization();

}

void obuCommSAN::CustomInitialization() {
//train arrival times depending on scheduling
for(int i=0; i<nTrains; i++) {
	arrivalTime->Index(i)->Mark()=i*trainScheduling;
}

//initial MAs
trainMAs->Index(0)->Mark()=lineLength;
for(int i=1; i<nTrains; i++) {
	trainMAs->Index(i)->Mark()=0;
}
}
obuCommSAN::~obuCommSAN(){
  for (int i = 0; i < NumStateVariables-NumReadOnlyPlaces; i++)
    delete LocalStateVariables[i];
};

void obuCommSAN::assignPlacesToActivitiesInst(){
  assigningID.Start = (Place*) LocalStateVariables[1];
  assigningID.waitForEntering = (Place*) LocalStateVariables[3];
  assigningID.TPRwaiting = (Place*) LocalStateVariables[8];
  assigningID.trainID = (Place*) LocalStateVariables[0];
  assigningID.Count = (Place*) LocalStateVariables[2];
  trainExits.trainHasToExit = (Place*) LocalStateVariables[9];
  trainExits.trainMovement = (Place*) LocalStateVariables[4];
}
void obuCommSAN::assignPlacesToActivitiesTimed(){
  trainArrival.waitForEntering = (Place*) LocalStateVariables[3];
  trainArrival.trainMovement = (Place*) LocalStateVariables[4];
  trainArrival.trainID = (Place*) LocalStateVariables[0];
  trainArrival.trainHeadPositions = (intArrayOfTrains*) LocalStateVariables[11];
  trainArrival.trainTailPositions = (intArrayOfTrains*) LocalStateVariables[12];
  trainArrival.trainMAs = (intArrayOfTrains*) LocalStateVariables[15];
  trainArrival.trainSpeeds = (shortArrayOfTrains*) LocalStateVariables[13];
  trainArrival.arrivalTime = (shortArrayOfTrains*) LocalStateVariables[10];
  updatePosition.trainMovement = (Place*) LocalStateVariables[4];
  updatePosition.trainID = (Place*) LocalStateVariables[0];
  updatePosition.trainHasToExit = (Place*) LocalStateVariables[9];
  updatePosition.trainHeadPositions = (intArrayOfTrains*) LocalStateVariables[11];
  updatePosition.trainSpeeds = (shortArrayOfTrains*) LocalStateVariables[13];
  updatePosition.trainTailPositions = (intArrayOfTrains*) LocalStateVariables[12];
  updatePosition.trainMAs = (intArrayOfTrains*) LocalStateVariables[15];
  TPRNetworkDelay_case1.sendTPR = (Place*) LocalStateVariables[5];
  TPRNetworkDelay_case1.TPRtoRBC = (Place*) LocalStateVariables[6];
  TPRNetworkDelay_case1.trainID = (Place*) LocalStateVariables[0];
  TPRNetworkDelay_case1.TPRmsg = (tprMsg*) LocalStateVariables[16];
  TPRNetworkDelay_case1.TPRmessages = (tprMsgArrayOfTrains*) LocalStateVariables[14];
  TPRNetworkDelay_case2.sendTPR = (Place*) LocalStateVariables[5];
  TPRNetworkDelay_case2.TPRmsg = (tprMsg*) LocalStateVariables[16];
  updateTPR_case1.TPRwaiting = (Place*) LocalStateVariables[8];
  updateTPR_case1.sendTPR = (Place*) LocalStateVariables[5];
  updateTPR_case1.TPRmsg = (tprMsg*) LocalStateVariables[16];
  updateTPR_case1.trainID = (Place*) LocalStateVariables[0];
  updateTPR_case1.trainHeadPositions = (intArrayOfTrains*) LocalStateVariables[11];
  updateTPR_case1.trainSpeeds = (shortArrayOfTrains*) LocalStateVariables[13];
  updateTPR_case2.TPRwaiting = (Place*) LocalStateVariables[8];
  updateTPR_case2.sendTPR = (Place*) LocalStateVariables[5];
  updateTPR_case2.TPRmsg = (tprMsg*) LocalStateVariables[16];
  updateTPR_case2.trainID = (Place*) LocalStateVariables[0];
  updateTPR_case2.trainHeadPositions = (intArrayOfTrains*) LocalStateVariables[11];
  updateTPR_case2.trainSpeeds = (shortArrayOfTrains*) LocalStateVariables[13];
  MANetworkDelay_case1.MAtoRBC = (Place*) LocalStateVariables[7];
  MANetworkDelay_case1.trainID = (Place*) LocalStateVariables[0];
  MANetworkDelay_case1.MAmessages = (maMsgOfTrains*) LocalStateVariables[17];
  MANetworkDelay_case1.trainMAs = (intArrayOfTrains*) LocalStateVariables[15];
  MANetworkDelay_case2.MAtoRBC = (Place*) LocalStateVariables[7];
  MANetworkDelay_case2.trainID = (Place*) LocalStateVariables[0];
  MANetworkDelay_case2.MAmessages = (maMsgOfTrains*) LocalStateVariables[17];
}
/*****************************************************************/
/*                  Activity Method Definitions                  */
/*****************************************************************/

/*======================assigningIDActivity========================*/


obuCommSAN::assigningIDActivity::assigningIDActivity(){
  ActivityInitialize("assigningID",5,Instantaneous , RaceEnabled, 5,1, false);
}

void obuCommSAN::assigningIDActivity::LinkVariables(){
  Start->Register(&Start_Mobius_Mark);
  waitForEntering->Register(&waitForEntering_Mobius_Mark);
  TPRwaiting->Register(&TPRwaiting_Mobius_Mark);
  trainID->Register(&trainID_Mobius_Mark);
  Count->Register(&Count_Mobius_Mark);
}

bool obuCommSAN::assigningIDActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(((*(Start_Mobius_Mark)) >=1));
  return NewEnabled;
}

double obuCommSAN::assigningIDActivity::Weight(){ 
  return 1;
}

bool obuCommSAN::assigningIDActivity::ReactivationPredicate(){ 
  return false;
}

bool obuCommSAN::assigningIDActivity::ReactivationFunction(){ 
  return false;
}

double obuCommSAN::assigningIDActivity::SampleDistribution(){
  return 0;
}

double* obuCommSAN::assigningIDActivity::ReturnDistributionParameters(){
    return NULL;
}

int obuCommSAN::assigningIDActivity::Rank(){
  return 1;
}

BaseActionClass* obuCommSAN::assigningIDActivity::Fire(){
  (*(Start_Mobius_Mark))--;
  trainID->Mark()=Count->Mark()-1;
Count->Mark()--;
  (*(waitForEntering_Mobius_Mark))++;
  (*(TPRwaiting_Mobius_Mark))++;
  return this;
}

/*======================trainExitsActivity========================*/


obuCommSAN::trainExitsActivity::trainExitsActivity(){
  ActivityInitialize("trainExits",6,Instantaneous , RaceEnabled, 2,2, false);
}

void obuCommSAN::trainExitsActivity::LinkVariables(){
  trainHasToExit->Register(&trainHasToExit_Mobius_Mark);
  trainMovement->Register(&trainMovement_Mobius_Mark);
}

bool obuCommSAN::trainExitsActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(((*(trainHasToExit_Mobius_Mark)) >=1)&&((*(trainMovement_Mobius_Mark)) >=1));
  return NewEnabled;
}

double obuCommSAN::trainExitsActivity::Weight(){ 
  return 1;
}

bool obuCommSAN::trainExitsActivity::ReactivationPredicate(){ 
  return false;
}

bool obuCommSAN::trainExitsActivity::ReactivationFunction(){ 
  return false;
}

double obuCommSAN::trainExitsActivity::SampleDistribution(){
  return 0;
}

double* obuCommSAN::trainExitsActivity::ReturnDistributionParameters(){
    return NULL;
}

int obuCommSAN::trainExitsActivity::Rank(){
  return 1;
}

BaseActionClass* obuCommSAN::trainExitsActivity::Fire(){
  (*(trainHasToExit_Mobius_Mark))--;
  (*(trainMovement_Mobius_Mark))--;
  return this;
}

/*======================trainArrivalActivity========================*/

obuCommSAN::trainArrivalActivity::trainArrivalActivity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("trainArrival",0,Deterministic, RaceEnabled, 7,1, false);
}

obuCommSAN::trainArrivalActivity::~trainArrivalActivity(){
  delete[] TheDistributionParameters;
}

void obuCommSAN::trainArrivalActivity::LinkVariables(){
  waitForEntering->Register(&waitForEntering_Mobius_Mark);
  trainMovement->Register(&trainMovement_Mobius_Mark);
  trainID->Register(&trainID_Mobius_Mark);





}

bool obuCommSAN::trainArrivalActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(((*(waitForEntering_Mobius_Mark)) >=1));
  return NewEnabled;
}

double obuCommSAN::trainArrivalActivity::DeterministicParamValue(){
  return arrivalTime->Index(trainID->Mark())->Mark();
  return 1.0;  // default rate if none is specified
}

double obuCommSAN::trainArrivalActivity::Weight(){ 
  return 1;
}

bool obuCommSAN::trainArrivalActivity::ReactivationPredicate(){ 
  return false;
}

bool obuCommSAN::trainArrivalActivity::ReactivationFunction(){ 
  return false;
}

double obuCommSAN::trainArrivalActivity::SampleDistribution(){
  return arrivalTime->Index(trainID->Mark())->Mark();
}

double* obuCommSAN::trainArrivalActivity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int obuCommSAN::trainArrivalActivity::Rank(){
  return 1;
}

BaseActionClass* obuCommSAN::trainArrivalActivity::Fire(){
  (*(waitForEntering_Mobius_Mark))--;
  //initial position of a train
trainHeadPositions->Index(trainID->Mark())->Mark()=0;
trainTailPositions->Index(trainID->Mark())->Mark()= -trainLength;

//evaluation of the speed for the next step
int speed = trainMAs->Index(trainID->Mark())->Mark() / positionUpdatePeriod; //approximation: the train should be stopped at the end of its MA
if(speed > maxTrainSpeed)
	speed = maxTrainSpeed;
trainSpeeds->Index(trainID->Mark())->Mark()=speed;
  (*(trainMovement_Mobius_Mark))++;
  return this;
}

/*======================updatePositionActivity========================*/

obuCommSAN::updatePositionActivity::updatePositionActivity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("updatePosition",1,Deterministic, RaceEnabled, 7,1, false);
}

obuCommSAN::updatePositionActivity::~updatePositionActivity(){
  delete[] TheDistributionParameters;
}

void obuCommSAN::updatePositionActivity::LinkVariables(){
  trainMovement->Register(&trainMovement_Mobius_Mark);
  trainID->Register(&trainID_Mobius_Mark);
  trainHasToExit->Register(&trainHasToExit_Mobius_Mark);




}

bool obuCommSAN::updatePositionActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(((*(trainMovement_Mobius_Mark)) >=1));
  return NewEnabled;
}

double obuCommSAN::updatePositionActivity::DeterministicParamValue(){
  return positionUpdatePeriod;
  return 1.0;  // default rate if none is specified
}

double obuCommSAN::updatePositionActivity::Weight(){ 
  return 1;
}

bool obuCommSAN::updatePositionActivity::ReactivationPredicate(){ 
  return false;
}

bool obuCommSAN::updatePositionActivity::ReactivationFunction(){ 
  return false;
}

double obuCommSAN::updatePositionActivity::SampleDistribution(){
  return positionUpdatePeriod;
}

double* obuCommSAN::updatePositionActivity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int obuCommSAN::updatePositionActivity::Rank(){
  return 1;
}

BaseActionClass* obuCommSAN::updatePositionActivity::Fire(){
  (*(trainMovement_Mobius_Mark))--;
  //update position of a train
int trainPosition = trainHeadPositions->Index(trainID->Mark())->Mark() + trainSpeeds->Index(trainID->Mark())->Mark()*positionUpdatePeriod;
trainHeadPositions->Index(trainID->Mark())->Mark() = trainPosition;
trainTailPositions->Index(trainID->Mark())->Mark()= trainPosition - trainLength;

//evaluation of the speed for the next step
if(trainPosition >= lineLength) {
	//speed is implicitly confirmed
	//train has to exit the line
	if((trainPosition + trainLength) >= lineLength)
		trainHasToExit->Mark()=1;
} else {
	int speed = (trainMAs->Index(trainID->Mark())->Mark()-trainPosition) / positionUpdatePeriod; //approximation: the train should be stopped at the end of its MA
	if(speed > maxTrainSpeed)
		speed = maxTrainSpeed;
	trainSpeeds->Index(trainID->Mark())->Mark()=speed;
}



  (*(trainMovement_Mobius_Mark))++;
  return this;
}

/*======================TPRNetworkDelayActivity_case1========================*/

obuCommSAN::TPRNetworkDelayActivity_case1::TPRNetworkDelayActivity_case1(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("TPRNetworkDelay_case1",2,Deterministic, RaceEnabled, 5,1, false);
}

obuCommSAN::TPRNetworkDelayActivity_case1::~TPRNetworkDelayActivity_case1(){
  delete[] TheDistributionParameters;
}

void obuCommSAN::TPRNetworkDelayActivity_case1::LinkVariables(){
  sendTPR->Register(&sendTPR_Mobius_Mark);
  TPRtoRBC->Register(&TPRtoRBC_Mobius_Mark);
  trainID->Register(&trainID_Mobius_Mark);


}

bool obuCommSAN::TPRNetworkDelayActivity_case1::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(((*(sendTPR_Mobius_Mark)) >=1));
  return NewEnabled;
}

double obuCommSAN::TPRNetworkDelayActivity_case1::DeterministicParamValue(){
  return TPRnetDelay;
  return 1.0;  // default rate if none is specified
}

double obuCommSAN::TPRNetworkDelayActivity_case1::Weight(){ 
  return 1-netNotDeliveryProb;
}

bool obuCommSAN::TPRNetworkDelayActivity_case1::ReactivationPredicate(){ 
  return false;
}

bool obuCommSAN::TPRNetworkDelayActivity_case1::ReactivationFunction(){ 
  return false;
}

double obuCommSAN::TPRNetworkDelayActivity_case1::SampleDistribution(){
  return TPRnetDelay;
}

double* obuCommSAN::TPRNetworkDelayActivity_case1::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int obuCommSAN::TPRNetworkDelayActivity_case1::Rank(){
  return 1;
}

BaseActionClass* obuCommSAN::TPRNetworkDelayActivity_case1::Fire(){
  (*(sendTPR_Mobius_Mark))--;
  TPRmessages->Index(trainID->Mark())->timestamp->Mark() = TPRmsg->timestamp->Mark();
TPRmessages->Index(trainID->Mark())->position->Mark() = TPRmsg->position->Mark();
TPRmessages->Index(trainID->Mark())->speed->Mark() = TPRmsg->speed->Mark();
TPRmessages->Index(trainID->Mark())->integrityConfirmed->Mark() = TPRmsg->integrityConfirmed->Mark();

TPRmsg->timestamp->Mark()=0;
  (*(TPRtoRBC_Mobius_Mark))++;
  return this;
}

/*======================TPRNetworkDelayActivity_case2========================*/

obuCommSAN::TPRNetworkDelayActivity_case2::TPRNetworkDelayActivity_case2(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("TPRNetworkDelay_case2",2,Deterministic, RaceEnabled, 2,1, false);
}

obuCommSAN::TPRNetworkDelayActivity_case2::~TPRNetworkDelayActivity_case2(){
  delete[] TheDistributionParameters;
}

void obuCommSAN::TPRNetworkDelayActivity_case2::LinkVariables(){
  sendTPR->Register(&sendTPR_Mobius_Mark);

}

bool obuCommSAN::TPRNetworkDelayActivity_case2::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(((*(sendTPR_Mobius_Mark)) >=1));
  return NewEnabled;
}

double obuCommSAN::TPRNetworkDelayActivity_case2::DeterministicParamValue(){
  return TPRnetDelay;
  return 1.0;  // default rate if none is specified
}

double obuCommSAN::TPRNetworkDelayActivity_case2::Weight(){ 
  return netNotDeliveryProb;
}

bool obuCommSAN::TPRNetworkDelayActivity_case2::ReactivationPredicate(){ 
  return false;
}

bool obuCommSAN::TPRNetworkDelayActivity_case2::ReactivationFunction(){ 
  return false;
}

double obuCommSAN::TPRNetworkDelayActivity_case2::SampleDistribution(){
  return TPRnetDelay;
}

double* obuCommSAN::TPRNetworkDelayActivity_case2::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int obuCommSAN::TPRNetworkDelayActivity_case2::Rank(){
  return 1;
}

BaseActionClass* obuCommSAN::TPRNetworkDelayActivity_case2::Fire(){
  (*(sendTPR_Mobius_Mark))--;
  TPRmsg->timestamp->Mark()=0;
  return this;
}

/*======================updateTPRActivity_case1========================*/

obuCommSAN::updateTPRActivity_case1::updateTPRActivity_case1(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("updateTPR_case1",3,Deterministic, RaceEnabled, 6,1, false);
}

obuCommSAN::updateTPRActivity_case1::~updateTPRActivity_case1(){
  delete[] TheDistributionParameters;
}

void obuCommSAN::updateTPRActivity_case1::LinkVariables(){
  TPRwaiting->Register(&TPRwaiting_Mobius_Mark);
  sendTPR->Register(&sendTPR_Mobius_Mark);

  trainID->Register(&trainID_Mobius_Mark);


}

bool obuCommSAN::updateTPRActivity_case1::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(((*(TPRwaiting_Mobius_Mark)) >=1));
  return NewEnabled;
}

double obuCommSAN::updateTPRActivity_case1::DeterministicParamValue(){
  return TPRUpdatePeriod;
  return 1.0;  // default rate if none is specified
}

double obuCommSAN::updateTPRActivity_case1::Weight(){ 
  return 1-integrityNotConfirmedProb;
}

bool obuCommSAN::updateTPRActivity_case1::ReactivationPredicate(){ 
  return false;
}

bool obuCommSAN::updateTPRActivity_case1::ReactivationFunction(){ 
  return false;
}

double obuCommSAN::updateTPRActivity_case1::SampleDistribution(){
  return TPRUpdatePeriod;
}

double* obuCommSAN::updateTPRActivity_case1::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int obuCommSAN::updateTPRActivity_case1::Rank(){
  return 1;
}

BaseActionClass* obuCommSAN::updateTPRActivity_case1::Fire(){
  (*(TPRwaiting_Mobius_Mark))--;
  TPRmsg->timestamp->Mark() = LastActionTime;
TPRmsg->position->Mark() = trainHeadPositions->Index(trainID->Mark())->Mark();
TPRmsg->speed->Mark() = trainSpeeds->Index(trainID->Mark())->Mark();
TPRmsg->integrityConfirmed->Mark() = 1;
  (*(sendTPR_Mobius_Mark))++;
  (*(TPRwaiting_Mobius_Mark))++;
  return this;
}

/*======================updateTPRActivity_case2========================*/

obuCommSAN::updateTPRActivity_case2::updateTPRActivity_case2(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("updateTPR_case2",3,Deterministic, RaceEnabled, 6,1, false);
}

obuCommSAN::updateTPRActivity_case2::~updateTPRActivity_case2(){
  delete[] TheDistributionParameters;
}

void obuCommSAN::updateTPRActivity_case2::LinkVariables(){
  TPRwaiting->Register(&TPRwaiting_Mobius_Mark);
  sendTPR->Register(&sendTPR_Mobius_Mark);

  trainID->Register(&trainID_Mobius_Mark);


}

bool obuCommSAN::updateTPRActivity_case2::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(((*(TPRwaiting_Mobius_Mark)) >=1));
  return NewEnabled;
}

double obuCommSAN::updateTPRActivity_case2::DeterministicParamValue(){
  return TPRUpdatePeriod;
  return 1.0;  // default rate if none is specified
}

double obuCommSAN::updateTPRActivity_case2::Weight(){ 
  return integrityNotConfirmedProb;
}

bool obuCommSAN::updateTPRActivity_case2::ReactivationPredicate(){ 
  return false;
}

bool obuCommSAN::updateTPRActivity_case2::ReactivationFunction(){ 
  return false;
}

double obuCommSAN::updateTPRActivity_case2::SampleDistribution(){
  return TPRUpdatePeriod;
}

double* obuCommSAN::updateTPRActivity_case2::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int obuCommSAN::updateTPRActivity_case2::Rank(){
  return 1;
}

BaseActionClass* obuCommSAN::updateTPRActivity_case2::Fire(){
  (*(TPRwaiting_Mobius_Mark))--;
  TPRmsg->timestamp->Mark() = LastActionTime;
TPRmsg->position->Mark() = trainHeadPositions->Index(trainID->Mark())->Mark();
TPRmsg->speed->Mark() = trainSpeeds->Index(trainID->Mark())->Mark();
TPRmsg->integrityConfirmed->Mark() = 0;
  (*(sendTPR_Mobius_Mark))++;
  (*(TPRwaiting_Mobius_Mark))++;
  return this;
}

/*======================MANetworkDelayActivity_case1========================*/

obuCommSAN::MANetworkDelayActivity_case1::MANetworkDelayActivity_case1(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("MANetworkDelay_case1",4,Deterministic, RaceEnabled, 4,3, false);
}

obuCommSAN::MANetworkDelayActivity_case1::~MANetworkDelayActivity_case1(){
  delete[] TheDistributionParameters;
}

void obuCommSAN::MANetworkDelayActivity_case1::LinkVariables(){
  MAtoRBC->Register(&MAtoRBC_Mobius_Mark);
  trainID->Register(&trainID_Mobius_Mark);


}

bool obuCommSAN::MANetworkDelayActivity_case1::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(((*(MAtoRBC_Mobius_Mark)) >=1)&&(MAmessages->Index(trainID->Mark())->timestamp->Mark()>0));
  return NewEnabled;
}

double obuCommSAN::MANetworkDelayActivity_case1::DeterministicParamValue(){
  return MAnetDelay;
  return 1.0;  // default rate if none is specified
}

double obuCommSAN::MANetworkDelayActivity_case1::Weight(){ 
  return 1-netNotDeliveryProb;
}

bool obuCommSAN::MANetworkDelayActivity_case1::ReactivationPredicate(){ 
  return false;
}

bool obuCommSAN::MANetworkDelayActivity_case1::ReactivationFunction(){ 
  return false;
}

double obuCommSAN::MANetworkDelayActivity_case1::SampleDistribution(){
  return MAnetDelay;
}

double* obuCommSAN::MANetworkDelayActivity_case1::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int obuCommSAN::MANetworkDelayActivity_case1::Rank(){
  return 1;
}

BaseActionClass* obuCommSAN::MANetworkDelayActivity_case1::Fire(){
  ;
  (*(MAtoRBC_Mobius_Mark))--;
  trainMAs->Index(trainID->Mark())->Mark() = MAmessages->Index(trainID->Mark())->EoA->Mark();
MAmessages->Index(trainID->Mark())->timestamp->Mark()=0;
  return this;
}

/*======================MANetworkDelayActivity_case2========================*/

obuCommSAN::MANetworkDelayActivity_case2::MANetworkDelayActivity_case2(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("MANetworkDelay_case2",4,Deterministic, RaceEnabled, 3,3, false);
}

obuCommSAN::MANetworkDelayActivity_case2::~MANetworkDelayActivity_case2(){
  delete[] TheDistributionParameters;
}

void obuCommSAN::MANetworkDelayActivity_case2::LinkVariables(){
  MAtoRBC->Register(&MAtoRBC_Mobius_Mark);
  trainID->Register(&trainID_Mobius_Mark);

}

bool obuCommSAN::MANetworkDelayActivity_case2::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(((*(MAtoRBC_Mobius_Mark)) >=1)&&(MAmessages->Index(trainID->Mark())->timestamp->Mark()>0));
  return NewEnabled;
}

double obuCommSAN::MANetworkDelayActivity_case2::DeterministicParamValue(){
  return MAnetDelay;
  return 1.0;  // default rate if none is specified
}

double obuCommSAN::MANetworkDelayActivity_case2::Weight(){ 
  return netNotDeliveryProb;
}

bool obuCommSAN::MANetworkDelayActivity_case2::ReactivationPredicate(){ 
  return false;
}

bool obuCommSAN::MANetworkDelayActivity_case2::ReactivationFunction(){ 
  return false;
}

double obuCommSAN::MANetworkDelayActivity_case2::SampleDistribution(){
  return MAnetDelay;
}

double* obuCommSAN::MANetworkDelayActivity_case2::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int obuCommSAN::MANetworkDelayActivity_case2::Rank(){
  return 1;
}

BaseActionClass* obuCommSAN::MANetworkDelayActivity_case2::Fire(){
  ;
  (*(MAtoRBC_Mobius_Mark))--;
  MAmessages->Index(trainID->Mark())->timestamp->Mark()=0;
  return this;
}

