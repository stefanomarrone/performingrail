#ifndef trainSAN_H_
#define trainSAN_H_

#include "Cpp/BaseClasses/EmptyGroup.h"
#include "Cpp/BaseClasses/GlobalVariables.h"
#include "Cpp/BaseClasses/PreselectGroup.h"
#include "Cpp/BaseClasses/PostselectGroup.h"
#include "Cpp/BaseClasses/state/StructStateVariable.h"
#include "Cpp/BaseClasses/state/ArrayStateVariable.h"
#include "Cpp/BaseClasses/SAN/SANModel.h" 
#include "Cpp/BaseClasses/SAN/Place.h"
#include "Cpp/BaseClasses/SAN/ExtendedPlace.h"
extern Short nTrains;
extern Short maxTrainSpeed;
extern Int trainLength;
extern Int lineLength;
extern Double positionUpdatePeriod;
extern Double TPRUpdatePeriod;
extern Double TPRnetDelay;
extern Double MAnetDelay;
extern Double integrityNotConfirmedProb;
extern Double netNotDeliveryProb;
extern Int trainScheduling;
extern UserDistributions* TheDistribution;

void MemoryError();

#ifndef _tprMsg_header_
#define _tprMsg_header_
typedef struct tprMsg_state {int timestamp; int position; short speed; short integrityConfirmed; };

class tprMsg: public StructStateVariable<tprMsg_state> {
  public:
  ExtendedPlace<int>* timestamp;
  ExtendedPlace<int>* position;
  ExtendedPlace<short>* speed;
  ExtendedPlace<short>* integrityConfirmed;
  tprMsg(char* name):
    StructStateVariable<tprMsg_state>(name, "") {
    timestamp = new ExtendedPlace<int>("timestamp", name);
    fields.push_back(field(ArrayType_INT, timestamp));
    position = new ExtendedPlace<int>("position", name);
    fields.push_back(field(ArrayType_INT, position));
    speed = new ExtendedPlace<short>("speed", name);
    fields.push_back(field(ArrayType_SHORT, speed));
    integrityConfirmed = new ExtendedPlace<short>("integrityConfirmed", name);
    fields.push_back(field(ArrayType_SHORT, integrityConfirmed));
    }
  tprMsg(char* name, char* fullname):
    StructStateVariable<tprMsg_state>(name, fullname) {
    char varname[strlen(fullname) + strlen(name) + 2];
    sprintf(varname, "%s.%s", fullname, name);
    timestamp = new ExtendedPlace<int>("timestamp", varname);
    fields.push_back(field(ArrayType_INT, timestamp));
    position = new ExtendedPlace<int>("position", varname);
    fields.push_back(field(ArrayType_INT, position));
    speed = new ExtendedPlace<short>("speed", varname);
    fields.push_back(field(ArrayType_SHORT, speed));
    integrityConfirmed = new ExtendedPlace<short>("integrityConfirmed", varname);
    fields.push_back(field(ArrayType_SHORT, integrityConfirmed));
    }
  tprMsg(char* name, tprMsg_state initialValue): 
    StructStateVariable<tprMsg_state>(name, "") {
    timestamp = new ExtendedPlace<int>("timestamp", name, initialValue.timestamp);
    fields.push_back(field(ArrayType_INT, timestamp));
    position = new ExtendedPlace<int>("position", name, initialValue.position);
    fields.push_back(field(ArrayType_INT, position));
    speed = new ExtendedPlace<short>("speed", name, initialValue.speed);
    fields.push_back(field(ArrayType_SHORT, speed));
    integrityConfirmed = new ExtendedPlace<short>("integrityConfirmed", name, initialValue.integrityConfirmed);
    fields.push_back(field(ArrayType_SHORT, integrityConfirmed));
    }
  tprMsg(char* name, char* fullname, tprMsg_state initialValue): 
    StructStateVariable<tprMsg_state>(name, fullname) {
    char varname[strlen(fullname) + strlen(name) + 2];
    sprintf(varname, "%s.%s", fullname, name);
    timestamp = new ExtendedPlace<int>("timestamp", varname, initialValue.timestamp);
    fields.push_back(field(ArrayType_INT, timestamp));
    sprintf(varname, "%s.%s", fullname, name);
    position = new ExtendedPlace<int>("position", varname, initialValue.position);
    fields.push_back(field(ArrayType_INT, position));
    sprintf(varname, "%s.%s", fullname, name);
    speed = new ExtendedPlace<short>("speed", varname, initialValue.speed);
    fields.push_back(field(ArrayType_SHORT, speed));
    sprintf(varname, "%s.%s", fullname, name);
    integrityConfirmed = new ExtendedPlace<short>("integrityConfirmed", varname, initialValue.integrityConfirmed);
    fields.push_back(field(ArrayType_SHORT, integrityConfirmed));
    }
  ~tprMsg() {
    for (fieldIterator i=fields.begin();i!=fields.end();++i)
      delete (*i).field;
  }
};
#endif
#ifndef _tprMsgArrayOfTrains_header_
#define _tprMsgArrayOfTrains_header_

typedef tprMsg_state tprMsgArrayOfTrains_state;
class tprMsgArrayOfTrains: public ArrayStateVariable<tprMsg > {
  public:
  tprMsgArrayOfTrains(char* name, char* fullname):
    ArrayStateVariable<tprMsg >(name, fullname, ArrayType_STRUCT ,nTrains) {
    char varname[12];
    char fqname[strlen(fullname) + strlen(name) + 2];
    sprintf(fqname, "%s%s", fullname, name);
    for (int i=0;i<nTrains;i++) {
      sprintf(varname,"%d",i);
      fields.push_back(new tprMsg(varname, fqname));
    }
  }

  tprMsgArrayOfTrains(char* name):
    ArrayStateVariable<tprMsg >(name, "", ArrayType_STRUCT ,nTrains) {
    char varname[12];
    for (int i=0;i<nTrains;i++) {
      sprintf(varname,"%d",i);
      fields.push_back(new tprMsg(varname, name));
    }
  }

  tprMsgArrayOfTrains(char* name, char* fullname, tprMsg_state & initialValue):
    ArrayStateVariable<tprMsg >(name, fullname, ArrayType_STRUCT ,nTrains) {
    char varname[12];
    char fqname[strlen(fullname) + strlen(name) + 2];
    sprintf(fqname, "%s%s", fullname, name);
    for (int i=0;i<nTrains;i++) {
      sprintf(varname,"%d",i);
      fields.push_back(new tprMsg(varname, fqname, initialValue));
    }
  }

  tprMsgArrayOfTrains(char* name, tprMsg_state & initialValue):
    ArrayStateVariable<tprMsg >(name, "", ArrayType_STRUCT ,nTrains) {
    char varname[12];
    for (int i=0;i<nTrains;i++) {
      sprintf(varname,"%d",i);
      fields.push_back(new tprMsg(varname, name, initialValue));
    }
  }

  tprMsgArrayOfTrains(char* name, char* fullname, tprMsg_state * initialValue):
    ArrayStateVariable<tprMsg >(name, fullname, ArrayType_STRUCT ,nTrains) {
    char varname[12];
    char fqname[strlen(fullname) + strlen(name) + 2];
    sprintf(fqname, "%s%s", fullname, name);
    for (int i=0;i<nTrains;i++) {
      sprintf(varname,"%d",i);
      fields.push_back(new tprMsg(varname, fqname, initialValue[i]));
    }
  }

  tprMsgArrayOfTrains(char* name, tprMsg_state * initialValue):
    ArrayStateVariable<tprMsg >(name, "", ArrayType_STRUCT ,nTrains) {
    char varname[12];
    for (int i=0;i<nTrains;i++) {
      sprintf(varname,"%d",i);
      fields.push_back(new tprMsg(varname, name, initialValue[i]));
    }
  }
  ~tprMsgArrayOfTrains() {
    for (fieldIterator i=fields.begin();i!=fields.end();++i)
      delete (*i);
  }
};
#endif
#ifndef _shortArrayOfTrains_header_
#define _shortArrayOfTrains_header_

typedef short shortArrayOfTrains_state;
class shortArrayOfTrains: public ArrayStateVariable<ExtendedPlace<short> > {
  public:
  shortArrayOfTrains(char* name, char* fullname):
    ArrayStateVariable<ExtendedPlace<short> >(name, fullname, ArrayType_SHORT ,nTrains) {
    char varname[12];
    char fqname[strlen(fullname) + strlen(name) + 2];
    sprintf(fqname, "%s%s", fullname, name);
    for (int i=0;i<nTrains;i++) {
      sprintf(varname,"%d",i);
      fields.push_back(new ExtendedPlace<short>(varname, fqname));
    }
  }

  shortArrayOfTrains(char* name):
    ArrayStateVariable<ExtendedPlace<short> >(name, "", ArrayType_SHORT ,nTrains) {
    char varname[12];
    for (int i=0;i<nTrains;i++) {
      sprintf(varname,"%d",i);
      fields.push_back(new ExtendedPlace<short>(varname, name));
    }
  }

  shortArrayOfTrains(char* name, char* fullname, short & initialValue):
    ArrayStateVariable<ExtendedPlace<short> >(name, fullname, ArrayType_SHORT ,nTrains) {
    char varname[12];
    char fqname[strlen(fullname) + strlen(name) + 2];
    sprintf(fqname, "%s%s", fullname, name);
    for (int i=0;i<nTrains;i++) {
      sprintf(varname,"%d",i);
      fields.push_back(new ExtendedPlace<short>(varname, fqname, initialValue));
    }
  }

  shortArrayOfTrains(char* name, short & initialValue):
    ArrayStateVariable<ExtendedPlace<short> >(name, "", ArrayType_SHORT ,nTrains) {
    char varname[12];
    for (int i=0;i<nTrains;i++) {
      sprintf(varname,"%d",i);
      fields.push_back(new ExtendedPlace<short>(varname, name, initialValue));
    }
  }

  shortArrayOfTrains(char* name, char* fullname, short * initialValue):
    ArrayStateVariable<ExtendedPlace<short> >(name, fullname, ArrayType_SHORT ,nTrains) {
    char varname[12];
    char fqname[strlen(fullname) + strlen(name) + 2];
    sprintf(fqname, "%s%s", fullname, name);
    for (int i=0;i<nTrains;i++) {
      sprintf(varname,"%d",i);
      fields.push_back(new ExtendedPlace<short>(varname, fqname, initialValue[i]));
    }
  }

  shortArrayOfTrains(char* name, short * initialValue):
    ArrayStateVariable<ExtendedPlace<short> >(name, "", ArrayType_SHORT ,nTrains) {
    char varname[12];
    for (int i=0;i<nTrains;i++) {
      sprintf(varname,"%d",i);
      fields.push_back(new ExtendedPlace<short>(varname, name, initialValue[i]));
    }
  }
  ~shortArrayOfTrains() {
    for (fieldIterator i=fields.begin();i!=fields.end();++i)
      delete (*i);
  }
};
#endif
#ifndef _intArrayOfTrains_header_
#define _intArrayOfTrains_header_

typedef int intArrayOfTrains_state;
class intArrayOfTrains: public ArrayStateVariable<ExtendedPlace<int> > {
  public:
  intArrayOfTrains(char* name, char* fullname):
    ArrayStateVariable<ExtendedPlace<int> >(name, fullname, ArrayType_INT ,nTrains) {
    char varname[12];
    char fqname[strlen(fullname) + strlen(name) + 2];
    sprintf(fqname, "%s%s", fullname, name);
    for (int i=0;i<nTrains;i++) {
      sprintf(varname,"%d",i);
      fields.push_back(new ExtendedPlace<int>(varname, fqname));
    }
  }

  intArrayOfTrains(char* name):
    ArrayStateVariable<ExtendedPlace<int> >(name, "", ArrayType_INT ,nTrains) {
    char varname[12];
    for (int i=0;i<nTrains;i++) {
      sprintf(varname,"%d",i);
      fields.push_back(new ExtendedPlace<int>(varname, name));
    }
  }

  intArrayOfTrains(char* name, char* fullname, int & initialValue):
    ArrayStateVariable<ExtendedPlace<int> >(name, fullname, ArrayType_INT ,nTrains) {
    char varname[12];
    char fqname[strlen(fullname) + strlen(name) + 2];
    sprintf(fqname, "%s%s", fullname, name);
    for (int i=0;i<nTrains;i++) {
      sprintf(varname,"%d",i);
      fields.push_back(new ExtendedPlace<int>(varname, fqname, initialValue));
    }
  }

  intArrayOfTrains(char* name, int & initialValue):
    ArrayStateVariable<ExtendedPlace<int> >(name, "", ArrayType_INT ,nTrains) {
    char varname[12];
    for (int i=0;i<nTrains;i++) {
      sprintf(varname,"%d",i);
      fields.push_back(new ExtendedPlace<int>(varname, name, initialValue));
    }
  }

  intArrayOfTrains(char* name, char* fullname, int * initialValue):
    ArrayStateVariable<ExtendedPlace<int> >(name, fullname, ArrayType_INT ,nTrains) {
    char varname[12];
    char fqname[strlen(fullname) + strlen(name) + 2];
    sprintf(fqname, "%s%s", fullname, name);
    for (int i=0;i<nTrains;i++) {
      sprintf(varname,"%d",i);
      fields.push_back(new ExtendedPlace<int>(varname, fqname, initialValue[i]));
    }
  }

  intArrayOfTrains(char* name, int * initialValue):
    ArrayStateVariable<ExtendedPlace<int> >(name, "", ArrayType_INT ,nTrains) {
    char varname[12];
    for (int i=0;i<nTrains;i++) {
      sprintf(varname,"%d",i);
      fields.push_back(new ExtendedPlace<int>(varname, name, initialValue[i]));
    }
  }
  ~intArrayOfTrains() {
    for (fieldIterator i=fields.begin();i!=fields.end();++i)
      delete (*i);
  }
};
#endif
#ifndef _maMsg_header_
#define _maMsg_header_
typedef struct maMsg_state {int timestamp; int EoA; };

class maMsg: public StructStateVariable<maMsg_state> {
  public:
  ExtendedPlace<int>* timestamp;
  ExtendedPlace<int>* EoA;
  maMsg(char* name):
    StructStateVariable<maMsg_state>(name, "") {
    timestamp = new ExtendedPlace<int>("timestamp", name);
    fields.push_back(field(ArrayType_INT, timestamp));
    EoA = new ExtendedPlace<int>("EoA", name);
    fields.push_back(field(ArrayType_INT, EoA));
    }
  maMsg(char* name, char* fullname):
    StructStateVariable<maMsg_state>(name, fullname) {
    char varname[strlen(fullname) + strlen(name) + 2];
    sprintf(varname, "%s.%s", fullname, name);
    timestamp = new ExtendedPlace<int>("timestamp", varname);
    fields.push_back(field(ArrayType_INT, timestamp));
    EoA = new ExtendedPlace<int>("EoA", varname);
    fields.push_back(field(ArrayType_INT, EoA));
    }
  maMsg(char* name, maMsg_state initialValue): 
    StructStateVariable<maMsg_state>(name, "") {
    timestamp = new ExtendedPlace<int>("timestamp", name, initialValue.timestamp);
    fields.push_back(field(ArrayType_INT, timestamp));
    EoA = new ExtendedPlace<int>("EoA", name, initialValue.EoA);
    fields.push_back(field(ArrayType_INT, EoA));
    }
  maMsg(char* name, char* fullname, maMsg_state initialValue): 
    StructStateVariable<maMsg_state>(name, fullname) {
    char varname[strlen(fullname) + strlen(name) + 2];
    sprintf(varname, "%s.%s", fullname, name);
    timestamp = new ExtendedPlace<int>("timestamp", varname, initialValue.timestamp);
    fields.push_back(field(ArrayType_INT, timestamp));
    sprintf(varname, "%s.%s", fullname, name);
    EoA = new ExtendedPlace<int>("EoA", varname, initialValue.EoA);
    fields.push_back(field(ArrayType_INT, EoA));
    }
  ~maMsg() {
    for (fieldIterator i=fields.begin();i!=fields.end();++i)
      delete (*i).field;
  }
};
#endif
#ifndef _maMsgOfTrains_header_
#define _maMsgOfTrains_header_

typedef maMsg_state maMsgOfTrains_state;
class maMsgOfTrains: public ArrayStateVariable<maMsg > {
  public:
  maMsgOfTrains(char* name, char* fullname):
    ArrayStateVariable<maMsg >(name, fullname, ArrayType_STRUCT ,nTrains) {
    char varname[12];
    char fqname[strlen(fullname) + strlen(name) + 2];
    sprintf(fqname, "%s%s", fullname, name);
    for (int i=0;i<nTrains;i++) {
      sprintf(varname,"%d",i);
      fields.push_back(new maMsg(varname, fqname));
    }
  }

  maMsgOfTrains(char* name):
    ArrayStateVariable<maMsg >(name, "", ArrayType_STRUCT ,nTrains) {
    char varname[12];
    for (int i=0;i<nTrains;i++) {
      sprintf(varname,"%d",i);
      fields.push_back(new maMsg(varname, name));
    }
  }

  maMsgOfTrains(char* name, char* fullname, maMsg_state & initialValue):
    ArrayStateVariable<maMsg >(name, fullname, ArrayType_STRUCT ,nTrains) {
    char varname[12];
    char fqname[strlen(fullname) + strlen(name) + 2];
    sprintf(fqname, "%s%s", fullname, name);
    for (int i=0;i<nTrains;i++) {
      sprintf(varname,"%d",i);
      fields.push_back(new maMsg(varname, fqname, initialValue));
    }
  }

  maMsgOfTrains(char* name, maMsg_state & initialValue):
    ArrayStateVariable<maMsg >(name, "", ArrayType_STRUCT ,nTrains) {
    char varname[12];
    for (int i=0;i<nTrains;i++) {
      sprintf(varname,"%d",i);
      fields.push_back(new maMsg(varname, name, initialValue));
    }
  }

  maMsgOfTrains(char* name, char* fullname, maMsg_state * initialValue):
    ArrayStateVariable<maMsg >(name, fullname, ArrayType_STRUCT ,nTrains) {
    char varname[12];
    char fqname[strlen(fullname) + strlen(name) + 2];
    sprintf(fqname, "%s%s", fullname, name);
    for (int i=0;i<nTrains;i++) {
      sprintf(varname,"%d",i);
      fields.push_back(new maMsg(varname, fqname, initialValue[i]));
    }
  }

  maMsgOfTrains(char* name, maMsg_state * initialValue):
    ArrayStateVariable<maMsg >(name, "", ArrayType_STRUCT ,nTrains) {
    char varname[12];
    for (int i=0;i<nTrains;i++) {
      sprintf(varname,"%d",i);
      fields.push_back(new maMsg(varname, name, initialValue[i]));
    }
  }
  ~maMsgOfTrains() {
    for (fieldIterator i=fields.begin();i!=fields.end();++i)
      delete (*i);
  }
};
#endif

/*********************************************************************
               trainSAN Submodel Definition                   
*********************************************************************/

class trainSAN:public SANModel{
public:

class assigningIDActivity:public Activity {
public:

  Place* Start;
  short* Start_Mobius_Mark;
  Place* waitForEntering;
  short* waitForEntering_Mobius_Mark;
  Place* TPRwaiting;
  short* TPRwaiting_Mobius_Mark;
  Place* trainID;
  short* trainID_Mobius_Mark;
  Place* Count;
  short* Count_Mobius_Mark;

  double* TheDistributionParameters;
  assigningIDActivity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
}; // assigningIDActivityActivity

class trainExitsActivity:public Activity {
public:

  Place* trainHasToExit;
  short* trainHasToExit_Mobius_Mark;
  Place* trainMovement;
  short* trainMovement_Mobius_Mark;

  double* TheDistributionParameters;
  trainExitsActivity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
}; // trainExitsActivityActivity

class trainArrivalActivity:public Activity {
public:

  Place* waitForEntering;
  short* waitForEntering_Mobius_Mark;
  Place* trainMovement;
  short* trainMovement_Mobius_Mark;
  Place* trainID;
  short* trainID_Mobius_Mark;
  intArrayOfTrains* trainHeadPositions;
  intArrayOfTrains* trainTailPositions;
  intArrayOfTrains* trainMAs;
  shortArrayOfTrains* trainSpeeds;
  shortArrayOfTrains* arrivalTime;

  double* TheDistributionParameters;
  trainArrivalActivity();
  ~trainArrivalActivity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // trainArrivalActivityActivity

class updatePositionActivity:public Activity {
public:

  Place* trainMovement;
  short* trainMovement_Mobius_Mark;
  Place* trainID;
  short* trainID_Mobius_Mark;
  Place* trainHasToExit;
  short* trainHasToExit_Mobius_Mark;
  intArrayOfTrains* trainHeadPositions;
  shortArrayOfTrains* trainSpeeds;
  intArrayOfTrains* trainTailPositions;
  intArrayOfTrains* trainMAs;

  double* TheDistributionParameters;
  updatePositionActivity();
  ~updatePositionActivity();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // updatePositionActivityActivity

class TPRNetworkDelayActivity_case1:public Activity {
public:

  Place* sendTPR;
  short* sendTPR_Mobius_Mark;
  Place* TPRtoRBC;
  short* TPRtoRBC_Mobius_Mark;
  Place* trainID;
  short* trainID_Mobius_Mark;
  tprMsg* TPRmsg;
  tprMsgArrayOfTrains* TPRmessages;

  double* TheDistributionParameters;
  TPRNetworkDelayActivity_case1();
  ~TPRNetworkDelayActivity_case1();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // TPRNetworkDelayActivity_case1Activity

class TPRNetworkDelayActivity_case2:public Activity {
public:

  Place* sendTPR;
  short* sendTPR_Mobius_Mark;
  tprMsg* TPRmsg;

  double* TheDistributionParameters;
  TPRNetworkDelayActivity_case2();
  ~TPRNetworkDelayActivity_case2();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // TPRNetworkDelayActivity_case2Activity

class updateTPRActivity_case1:public Activity {
public:

  Place* TPRwaiting;
  short* TPRwaiting_Mobius_Mark;
  Place* sendTPR;
  short* sendTPR_Mobius_Mark;
  tprMsg* TPRmsg;
  Place* trainID;
  short* trainID_Mobius_Mark;
  intArrayOfTrains* trainHeadPositions;
  shortArrayOfTrains* trainSpeeds;

  double* TheDistributionParameters;
  updateTPRActivity_case1();
  ~updateTPRActivity_case1();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // updateTPRActivity_case1Activity

class updateTPRActivity_case2:public Activity {
public:

  Place* TPRwaiting;
  short* TPRwaiting_Mobius_Mark;
  Place* sendTPR;
  short* sendTPR_Mobius_Mark;
  tprMsg* TPRmsg;
  Place* trainID;
  short* trainID_Mobius_Mark;
  intArrayOfTrains* trainHeadPositions;
  shortArrayOfTrains* trainSpeeds;

  double* TheDistributionParameters;
  updateTPRActivity_case2();
  ~updateTPRActivity_case2();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // updateTPRActivity_case2Activity

class MANetworkDelayActivity_case1:public Activity {
public:

  Place* MAtoRBC;
  short* MAtoRBC_Mobius_Mark;
  Place* trainID;
  short* trainID_Mobius_Mark;
  maMsgOfTrains* MAmessages;
  intArrayOfTrains* trainMAs;

  double* TheDistributionParameters;
  MANetworkDelayActivity_case1();
  ~MANetworkDelayActivity_case1();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // MANetworkDelayActivity_case1Activity

class MANetworkDelayActivity_case2:public Activity {
public:

  Place* MAtoRBC;
  short* MAtoRBC_Mobius_Mark;
  Place* trainID;
  short* trainID_Mobius_Mark;
  maMsgOfTrains* MAmessages;

  double* TheDistributionParameters;
  MANetworkDelayActivity_case2();
  ~MANetworkDelayActivity_case2();
  double Rate(){return 0;}
  bool Enabled();
  void LinkVariables();
  double Weight();
  bool ReactivationPredicate();
  bool ReactivationFunction();
  double SampleDistribution();
  double* ReturnDistributionParameters();
  int Rank();
  BaseActionClass* Fire();
  double DeterministicParamValue();
}; // MANetworkDelayActivity_case2Activity

  //List of user-specified place names
  Place* trainID;
  Place* Start;
  Place* Count;
  Place* waitForEntering;
  Place* trainMovement;
  Place* sendTPR;
  Place* TPRtoRBC;
  Place* MAtoRBC;
  Place* TPRwaiting;
  Place* trainHasToExit;
  shortArrayOfTrains* arrivalTime;
  intArrayOfTrains* trainHeadPositions;
  intArrayOfTrains* trainTailPositions;
  shortArrayOfTrains* trainSpeeds;
  tprMsgArrayOfTrains* TPRmessages;
  intArrayOfTrains* trainMAs;
  tprMsg* TPRmsg;
  maMsgOfTrains* MAmessages;

  // Create instances of all actvities
  assigningIDActivity assigningID;
  trainExitsActivity trainExits;
  trainArrivalActivity trainArrival;
  updatePositionActivity updatePosition;
  TPRNetworkDelayActivity_case1 TPRNetworkDelay_case1;
  TPRNetworkDelayActivity_case2 TPRNetworkDelay_case2;
  updateTPRActivity_case1 updateTPR_case1;
  updateTPRActivity_case2 updateTPR_case2;
  MANetworkDelayActivity_case1 MANetworkDelay_case1;
  MANetworkDelayActivity_case2 MANetworkDelay_case2;
  //Create instances of all groups 
  PreselectGroup ImmediateGroup;
  PostselectGroup assigningIDGroup;
  PostselectGroup trainExitsGroup;
  PostselectGroup TPRNetworkDelayGroup;  PostselectGroup updateTPRGroup;  PostselectGroup MANetworkDelayGroup;
  trainSAN();
  ~trainSAN();
  void CustomInitialization();

  void assignPlacesToActivitiesInst();
  void assignPlacesToActivitiesTimed();
}; // end trainSAN

#endif // trainSAN_H_
