

// This C++ file was created by SanEditor

#include "Atomic/trackside/tracksideSAN.h"

#include <stdlib.h>
#include <iostream>

#include <math.h>


/*****************************************************************
                         tracksideSAN Constructor             
******************************************************************/


tracksideSAN::tracksideSAN(){


  Activity* InitialActionList[2]={
    &evaluateOlderTPR, //0
    &RBCprocessing  // 1
  };

  BaseGroupClass* InitialGroupList[2]={
    (BaseGroupClass*) &(RBCprocessing), 
    (BaseGroupClass*) &(evaluateOlderTPR)
  };

  TPRtoRBC = new Place("TPRtoRBC" ,0);
  MAtoRBC = new Place("MAtoRBC" ,0);
  idle = new Place("idle" ,1);
  msgIn = new Place("msgIn" ,0);
  tprMsg_state temp_TPRmessagestprMsgArrayOfTrainsvalue = {0,0,0,0};
  TPRmessages = new tprMsgArrayOfTrains("TPRmessages",temp_TPRmessagestprMsgArrayOfTrainsvalue);
  int temp_trackStatusAreasHeadsintArrayOfTrainsvalue = 0;
  trackStatusAreasHeads = new intArrayOfTrains("trackStatusAreasHeads",temp_trackStatusAreasHeadsintArrayOfTrainsvalue);
  int temp_trackStatusAreasTailsintArrayOfTrainsvalue = 0;
  trackStatusAreasTails = new intArrayOfTrains("trackStatusAreasTails",temp_trackStatusAreasTailsintArrayOfTrainsvalue);
  maMsg_state temp_MAmessagesmaMsgOfTrainsvalue = {0,0};
  MAmessages = new maMsgOfTrains("MAmessages",temp_MAmessagesmaMsgOfTrainsvalue);
  BaseStateVariableClass* InitialPlaces[8]={
    TPRtoRBC,  // 0
    MAtoRBC,  // 1
    idle,  // 2
    msgIn,  // 3
    TPRmessages,  // 4
    trackStatusAreasHeads,  // 5
    trackStatusAreasTails,  // 6
    MAmessages   // 7
  };
  BaseStateVariableClass* InitialROPlaces[0]={
  };
  initializeSANModelNow("trackside", 8, InitialPlaces, 
                        0, InitialROPlaces, 
                        2, InitialActionList, 2, InitialGroupList);


  assignPlacesToActivitiesInst();
  assignPlacesToActivitiesTimed();

  int AffectArcs[10][2]={ 
    {0,0}, {2,0}, {3,0}, {3,1}, {1,1}, {2,1}, {4,1}, {6,1}, {5,1}, 
    {7,1}
  };
  for(int n=0;n<10;n++) {
    AddAffectArc(InitialPlaces[AffectArcs[n][0]],
                 InitialActionList[AffectArcs[n][1]]);
  }
  int EnableArcs[3][2]={ 
    {0,0}, {2,0}, {3,1}
  };
  for(int n=0;n<3;n++) {
    AddEnableArc(InitialPlaces[EnableArcs[n][0]],
                 InitialActionList[EnableArcs[n][1]]);
  }

  for(int n=0;n<2;n++) {
    InitialActionList[n]->LinkVariables();
  }
  CustomInitialization();

}

void tracksideSAN::CustomInitialization() {
//initial track status areas
trackStatusAreasHeads->Index(0)->Mark()=lineLength;
for(int i=1; i<nTrains; i++) {
	trackStatusAreasHeads->Index(i)->Mark()=0;
}
}
tracksideSAN::~tracksideSAN(){
  for (int i = 0; i < NumStateVariables-NumReadOnlyPlaces; i++)
    delete LocalStateVariables[i];
};

void tracksideSAN::assignPlacesToActivitiesInst(){
  evaluateOlderTPR.TPRtoRBC = (Place*) LocalStateVariables[0];
  evaluateOlderTPR.idle = (Place*) LocalStateVariables[2];
  evaluateOlderTPR.msgIn = (Place*) LocalStateVariables[3];
}
void tracksideSAN::assignPlacesToActivitiesTimed(){
  RBCprocessing.msgIn = (Place*) LocalStateVariables[3];
  RBCprocessing.MAtoRBC = (Place*) LocalStateVariables[1];
  RBCprocessing.idle = (Place*) LocalStateVariables[2];
  RBCprocessing.TPRmessages = (tprMsgArrayOfTrains*) LocalStateVariables[4];
  RBCprocessing.trackStatusAreasTails = (intArrayOfTrains*) LocalStateVariables[6];
  RBCprocessing.trackStatusAreasHeads = (intArrayOfTrains*) LocalStateVariables[5];
  RBCprocessing.MAmessages = (maMsgOfTrains*) LocalStateVariables[7];
}
/*****************************************************************/
/*                  Activity Method Definitions                  */
/*****************************************************************/

/*======================evaluateOlderTPRActivity========================*/


tracksideSAN::evaluateOlderTPRActivity::evaluateOlderTPRActivity(){
  ActivityInitialize("evaluateOlderTPR",1,Instantaneous , RaceEnabled, 3,2, false);
}

void tracksideSAN::evaluateOlderTPRActivity::LinkVariables(){
  TPRtoRBC->Register(&TPRtoRBC_Mobius_Mark);
  idle->Register(&idle_Mobius_Mark);
  msgIn->Register(&msgIn_Mobius_Mark);
}

bool tracksideSAN::evaluateOlderTPRActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(((*(TPRtoRBC_Mobius_Mark)) >=1)&&((*(idle_Mobius_Mark)) >=1));
  return NewEnabled;
}

double tracksideSAN::evaluateOlderTPRActivity::Weight(){ 
  return 1;
}

bool tracksideSAN::evaluateOlderTPRActivity::ReactivationPredicate(){ 
  return false;
}

bool tracksideSAN::evaluateOlderTPRActivity::ReactivationFunction(){ 
  return false;
}

double tracksideSAN::evaluateOlderTPRActivity::SampleDistribution(){
  return 0;
}

double* tracksideSAN::evaluateOlderTPRActivity::ReturnDistributionParameters(){
    return NULL;
}

int tracksideSAN::evaluateOlderTPRActivity::Rank(){
  return 1;
}

BaseActionClass* tracksideSAN::evaluateOlderTPRActivity::Fire(){
  (*(TPRtoRBC_Mobius_Mark))--;
  (*(idle_Mobius_Mark))--;
  (*(msgIn_Mobius_Mark))++;
  return this;
}

/*======================RBCprocessingActivity========================*/

tracksideSAN::RBCprocessingActivity::RBCprocessingActivity(){
  TheDistributionParameters = new double[1];
  ActivityInitialize("RBCprocessing",0,Deterministic, RaceEnabled, 7,1, false);
}

tracksideSAN::RBCprocessingActivity::~RBCprocessingActivity(){
  delete[] TheDistributionParameters;
}

void tracksideSAN::RBCprocessingActivity::LinkVariables(){
  msgIn->Register(&msgIn_Mobius_Mark);
  MAtoRBC->Register(&MAtoRBC_Mobius_Mark);
  idle->Register(&idle_Mobius_Mark);




}

bool tracksideSAN::RBCprocessingActivity::Enabled(){
  OldEnabled=NewEnabled;
  NewEnabled=(((*(msgIn_Mobius_Mark)) >=1));
  return NewEnabled;
}

double tracksideSAN::RBCprocessingActivity::DeterministicParamValue(){
  return RBCprocessingTime;
  return 1.0;  // default rate if none is specified
}

double tracksideSAN::RBCprocessingActivity::Weight(){ 
  return 1;
}

bool tracksideSAN::RBCprocessingActivity::ReactivationPredicate(){ 
  return false;
}

bool tracksideSAN::RBCprocessingActivity::ReactivationFunction(){ 
  return false;
}

double tracksideSAN::RBCprocessingActivity::SampleDistribution(){
  return RBCprocessingTime;
}

double* tracksideSAN::RBCprocessingActivity::ReturnDistributionParameters(){
  TheDistributionParameters[0] = DeterministicParamValue();
  return TheDistributionParameters;
}

int tracksideSAN::RBCprocessingActivity::Rank(){
  return 1;
}

BaseActionClass* tracksideSAN::RBCprocessingActivity::Fire(){
  (*(msgIn_Mobius_Mark))--;
  //receives older message
short sender = 0;
int timestamp = TPRmessages->Index(0)->timestamp->Mark();
for(int i=1; i<nTrains; i++) {
	if(timestamp==0 || 
		(TPRmessages->Index(i)->timestamp->Mark()>0 && TPRmessages->Index(i)->timestamp->Mark()<timestamp)) {
		sender=i;
		timestamp = TPRmessages->Index(i)->timestamp->Mark();
	}
}
int position = TPRmessages->Index(sender)->position->Mark();
short integrityConfirmed = TPRmessages->Index(sender)->integrityConfirmed->Mark();

//clear the message
TPRmessages->Index(sender)->timestamp->Mark() = 0;

//update the track status areas
//trackStatusAreasHeads->Index(sender)->Mark() = position;

if(integrityConfirmed == 1) {
	trackStatusAreasTails->Index(sender)->Mark() = position + trainLength;
	if(sender < nTrains-1) {
		trackStatusAreasHeads->Index(sender+1)->Mark() = position + trainLength + safetyMargin;
		if(trackStatusAreasHeads->Index(sender+1)->Mark() > lineLength) {
			trackStatusAreasHeads->Index(sender+1)->Mark() = lineLength;
		}
	}
}

//evaluate MA for the train
MAmessages->Index(sender)->timestamp->Mark() = LastActionTime;
MAmessages->Index(sender)->EoA->Mark() = trackStatusAreasHeads->Index(sender)->Mark();
  (*(MAtoRBC_Mobius_Mark))++;
  (*(idle_Mobius_Mark))++;
  return this;
}

