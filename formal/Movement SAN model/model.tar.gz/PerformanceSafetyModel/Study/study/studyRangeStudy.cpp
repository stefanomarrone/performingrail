
#include "Study/study/studyRangeStudy.h"

//******************************************************
//Global Variables
//******************************************************
Double MAnetDelay;
Double RBCprocessingTime;
Double TPRUpdatePeriod;
Double TPRnetDelay;
Double integrityNotConfirmedProb;
Int lineLength;
Short maxTrainSpeed;
Short nTrains;
Double netNotDeliveryProb;
Double positionUpdatePeriod;
Int safetyMargin;
Int trainLength;
Int trainScheduling;

//********************************************************
//studyRangeStudy Constructor
//********************************************************
studyRangeStudy::studyRangeStudy() {

  // define arrays of global variable names and types
  NumGVs = 13;
  NumExps = 11;

  GVNames = new char*[NumGVs];
  GVTypes = new char*[NumGVs];
  GVNames[0]=strdup("MAnetDelay");
  GVTypes[0]=strdup("double");
  GVNames[1]=strdup("RBCprocessingTime");
  GVTypes[1]=strdup("double");
  GVNames[2]=strdup("TPRUpdatePeriod");
  GVTypes[2]=strdup("double");
  GVNames[3]=strdup("TPRnetDelay");
  GVTypes[3]=strdup("double");
  GVNames[4]=strdup("integrityNotConfirmedProb");
  GVTypes[4]=strdup("double");
  GVNames[5]=strdup("lineLength");
  GVTypes[5]=strdup("int");
  GVNames[6]=strdup("maxTrainSpeed");
  GVTypes[6]=strdup("short");
  GVNames[7]=strdup("nTrains");
  GVTypes[7]=strdup("short");
  GVNames[8]=strdup("netNotDeliveryProb");
  GVTypes[8]=strdup("double");
  GVNames[9]=strdup("positionUpdatePeriod");
  GVTypes[9]=strdup("double");
  GVNames[10]=strdup("safetyMargin");
  GVTypes[10]=strdup("int");
  GVNames[11]=strdup("trainLength");
  GVTypes[11]=strdup("int");
  GVNames[12]=strdup("trainScheduling");
  GVTypes[12]=strdup("int");

  // create the arrays to store the values of each gv
  MAnetDelayValues = new double[NumExps];
  RBCprocessingTimeValues = new double[NumExps];
  TPRUpdatePeriodValues = new double[NumExps];
  TPRnetDelayValues = new double[NumExps];
  integrityNotConfirmedProbValues = new double[NumExps];
  lineLengthValues = new int[NumExps];
  maxTrainSpeedValues = new short[NumExps];
  nTrainsValues = new short[NumExps];
  netNotDeliveryProbValues = new double[NumExps];
  positionUpdatePeriodValues = new double[NumExps];
  safetyMarginValues = new int[NumExps];
  trainLengthValues = new int[NumExps];
  trainSchedulingValues = new int[NumExps];

  // call methods to assign values to each gv
  SetValues_MAnetDelay();
  SetValues_RBCprocessingTime();
  SetValues_TPRUpdatePeriod();
  SetValues_TPRnetDelay();
  SetValues_integrityNotConfirmedProb();
  SetValues_lineLength();
  SetValues_maxTrainSpeed();
  SetValues_nTrains();
  SetValues_netNotDeliveryProb();
  SetValues_positionUpdatePeriod();
  SetValues_safetyMargin();
  SetValues_trainLength();
  SetValues_trainScheduling();
  SetDefaultMobiusRoot(MOBIUSROOT);
}


//******************************************************
//studyRangeStudy Destructor
//******************************************************
studyRangeStudy::~studyRangeStudy() {
  delete [] MAnetDelayValues;
  delete [] RBCprocessingTimeValues;
  delete [] TPRUpdatePeriodValues;
  delete [] TPRnetDelayValues;
  delete [] integrityNotConfirmedProbValues;
  delete [] lineLengthValues;
  delete [] maxTrainSpeedValues;
  delete [] nTrainsValues;
  delete [] netNotDeliveryProbValues;
  delete [] positionUpdatePeriodValues;
  delete [] safetyMarginValues;
  delete [] trainLengthValues;
  delete [] trainSchedulingValues;
  delete ThePVModel;
}


//******************************************************
// set values for MAnetDelay
//******************************************************
void studyRangeStudy::SetValues_MAnetDelay() {
  for (int n=0; n<NumExps; n++)
    MAnetDelayValues[n] = 0.2;
}


//******************************************************
// set values for RBCprocessingTime
//******************************************************
void studyRangeStudy::SetValues_RBCprocessingTime() {
  for (int n=0; n<NumExps; n++)
    RBCprocessingTimeValues[n] = 0.2;
}


//******************************************************
// set values for TPRUpdatePeriod
//******************************************************
void studyRangeStudy::SetValues_TPRUpdatePeriod() {
  for (int n=0; n<NumExps; n++)
    TPRUpdatePeriodValues[n] = 5.0;
}


//******************************************************
// set values for TPRnetDelay
//******************************************************
void studyRangeStudy::SetValues_TPRnetDelay() {
  for (int n=0; n<NumExps; n++)
    TPRnetDelayValues[n] = 0.5;
}


//******************************************************
// set values for integrityNotConfirmedProb
//******************************************************
void studyRangeStudy::SetValues_integrityNotConfirmedProb() {
  for (int n=0; n<NumExps; n++)
    integrityNotConfirmedProbValues[n] = 0.0;
}


//******************************************************
// set values for lineLength
//******************************************************
void studyRangeStudy::SetValues_lineLength() {
  for (int n=0; n<NumExps; n++)
    lineLengthValues[n] = 16000;
}


//******************************************************
// set values for maxTrainSpeed
//******************************************************
void studyRangeStudy::SetValues_maxTrainSpeed() {
  for (int n=0; n<NumExps; n++)
    maxTrainSpeedValues[n] = 80;
}


//******************************************************
// set values for nTrains
//******************************************************
void studyRangeStudy::SetValues_nTrains() {
  for (int n=0; n<NumExps; n++)
    nTrainsValues[n] = 30;
}


//******************************************************
// set values for netNotDeliveryProb
//******************************************************
void studyRangeStudy::SetValues_netNotDeliveryProb() {
  netNotDeliveryProbValues[0] = 0.0;
  netNotDeliveryProbValues[1] = 0.1;
  netNotDeliveryProbValues[2] = 0.2;
  netNotDeliveryProbValues[3] = 0.30000000000000004;
  netNotDeliveryProbValues[4] = 0.4;
  netNotDeliveryProbValues[5] = 0.5;
  netNotDeliveryProbValues[6] = 0.6;
  netNotDeliveryProbValues[7] = 0.7;
  netNotDeliveryProbValues[8] = 0.7999999999999999;
  netNotDeliveryProbValues[9] = 0.8999999999999999;
  netNotDeliveryProbValues[10] = 0.9999999999999999;
}


//******************************************************
// set values for positionUpdatePeriod
//******************************************************
void studyRangeStudy::SetValues_positionUpdatePeriod() {
  for (int n=0; n<NumExps; n++)
    positionUpdatePeriodValues[n] = 1.0;
}


//******************************************************
// set values for safetyMargin
//******************************************************
void studyRangeStudy::SetValues_safetyMargin() {
  for (int n=0; n<NumExps; n++)
    safetyMarginValues[n] = 0;
}


//******************************************************
// set values for trainLength
//******************************************************
void studyRangeStudy::SetValues_trainLength() {
  for (int n=0; n<NumExps; n++)
    trainLengthValues[n] = 300;
}


//******************************************************
// set values for trainScheduling
//******************************************************
void studyRangeStudy::SetValues_trainScheduling() {
  for (int n=0; n<NumExps; n++)
    trainSchedulingValues[n] = 50;
}



//******************************************************
//print values of gv (for debugging)
//******************************************************
void studyRangeStudy::PrintGlobalValues(int expNum) {
  if (NumGVs == 0) {
    cout<<"There are no global variables."<<endl;
    return;
  }

  SetGVs(expNum);

  cout<<"The Global Variable values for experiment "<<
    GetExpName(expNum)<<" are:"<<endl;
  cout << "MAnetDelay\tdouble\t" << MAnetDelay << endl;
  cout << "RBCprocessingTime\tdouble\t" << RBCprocessingTime << endl;
  cout << "TPRUpdatePeriod\tdouble\t" << TPRUpdatePeriod << endl;
  cout << "TPRnetDelay\tdouble\t" << TPRnetDelay << endl;
  cout << "integrityNotConfirmedProb\tdouble\t" << integrityNotConfirmedProb << endl;
  cout << "lineLength\tint\t" << lineLength << endl;
  cout << "maxTrainSpeed\tshort\t" << maxTrainSpeed << endl;
  cout << "nTrains\tshort\t" << nTrains << endl;
  cout << "netNotDeliveryProb\tdouble\t" << netNotDeliveryProb << endl;
  cout << "positionUpdatePeriod\tdouble\t" << positionUpdatePeriod << endl;
  cout << "safetyMargin\tint\t" << safetyMargin << endl;
  cout << "trainLength\tint\t" << trainLength << endl;
  cout << "trainScheduling\tint\t" << trainScheduling << endl;
}


//******************************************************
//retrieve the value of a global variable
//******************************************************
void *studyRangeStudy::GetGVValue(char *TheGVName) {
  if (strcmp("MAnetDelay", TheGVName) == 0)
    return &MAnetDelay;
  else if (strcmp("RBCprocessingTime", TheGVName) == 0)
    return &RBCprocessingTime;
  else if (strcmp("TPRUpdatePeriod", TheGVName) == 0)
    return &TPRUpdatePeriod;
  else if (strcmp("TPRnetDelay", TheGVName) == 0)
    return &TPRnetDelay;
  else if (strcmp("integrityNotConfirmedProb", TheGVName) == 0)
    return &integrityNotConfirmedProb;
  else if (strcmp("lineLength", TheGVName) == 0)
    return &lineLength;
  else if (strcmp("maxTrainSpeed", TheGVName) == 0)
    return &maxTrainSpeed;
  else if (strcmp("nTrains", TheGVName) == 0)
    return &nTrains;
  else if (strcmp("netNotDeliveryProb", TheGVName) == 0)
    return &netNotDeliveryProb;
  else if (strcmp("positionUpdatePeriod", TheGVName) == 0)
    return &positionUpdatePeriod;
  else if (strcmp("safetyMargin", TheGVName) == 0)
    return &safetyMargin;
  else if (strcmp("trainLength", TheGVName) == 0)
    return &trainLength;
  else if (strcmp("trainScheduling", TheGVName) == 0)
    return &trainScheduling;
  else 
    cerr<<"!! studyRangeStudy::GetGVValue: Global Variable "<<TheGVName<<" does not exist."<<endl;
  return NULL;
}


//******************************************************
//override the value of a global variable
//******************************************************
void studyRangeStudy::OverrideGVValue(char *TheGVName,void *TheGVValue) {
  if (strcmp("MAnetDelay", TheGVName) == 0)
    SetGvValue(MAnetDelay, *(double *)TheGVValue);
  else if (strcmp("RBCprocessingTime", TheGVName) == 0)
    SetGvValue(RBCprocessingTime, *(double *)TheGVValue);
  else if (strcmp("TPRUpdatePeriod", TheGVName) == 0)
    SetGvValue(TPRUpdatePeriod, *(double *)TheGVValue);
  else if (strcmp("TPRnetDelay", TheGVName) == 0)
    SetGvValue(TPRnetDelay, *(double *)TheGVValue);
  else if (strcmp("integrityNotConfirmedProb", TheGVName) == 0)
    SetGvValue(integrityNotConfirmedProb, *(double *)TheGVValue);
  else if (strcmp("lineLength", TheGVName) == 0)
    SetGvValue(lineLength, *(int *)TheGVValue);
  else if (strcmp("maxTrainSpeed", TheGVName) == 0)
    SetGvValue(maxTrainSpeed, *(short *)TheGVValue);
  else if (strcmp("nTrains", TheGVName) == 0)
    SetGvValue(nTrains, *(short *)TheGVValue);
  else if (strcmp("netNotDeliveryProb", TheGVName) == 0)
    SetGvValue(netNotDeliveryProb, *(double *)TheGVValue);
  else if (strcmp("positionUpdatePeriod", TheGVName) == 0)
    SetGvValue(positionUpdatePeriod, *(double *)TheGVValue);
  else if (strcmp("safetyMargin", TheGVName) == 0)
    SetGvValue(safetyMargin, *(int *)TheGVValue);
  else if (strcmp("trainLength", TheGVName) == 0)
    SetGvValue(trainLength, *(int *)TheGVValue);
  else if (strcmp("trainScheduling", TheGVName) == 0)
    SetGvValue(trainScheduling, *(int *)TheGVValue);
  else 
    cerr<<"!! studyRangeStudy::OverrideGVValue: Global Variable "<<TheGVName<<" does not exist."<<endl;
}


//******************************************************
//set the value of all global variables to the given exp
//******************************************************
void studyRangeStudy::SetGVs(int expNum) {
  SetGvValue(MAnetDelay, MAnetDelayValues[expNum]);
  SetGvValue(RBCprocessingTime, RBCprocessingTimeValues[expNum]);
  SetGvValue(TPRUpdatePeriod, TPRUpdatePeriodValues[expNum]);
  SetGvValue(TPRnetDelay, TPRnetDelayValues[expNum]);
  SetGvValue(integrityNotConfirmedProb, integrityNotConfirmedProbValues[expNum]);
  SetGvValue(lineLength, lineLengthValues[expNum]);
  SetGvValue(maxTrainSpeed, maxTrainSpeedValues[expNum]);
  SetGvValue(nTrains, nTrainsValues[expNum]);
  SetGvValue(netNotDeliveryProb, netNotDeliveryProbValues[expNum]);
  SetGvValue(positionUpdatePeriod, positionUpdatePeriodValues[expNum]);
  SetGvValue(safetyMargin, safetyMarginValues[expNum]);
  SetGvValue(trainLength, trainLengthValues[expNum]);
  SetGvValue(trainScheduling, trainSchedulingValues[expNum]);
}


//******************************************************
//static class method called by solvers to create study 
//(and thus create all of the model)
//******************************************************
BaseStudyClass* GlobalStudyPtr = NULL;
BaseStudyClass * GenerateStudy() {
  if (GlobalStudyPtr == NULL)
    GlobalStudyPtr = new studyRangeStudy();
  return GlobalStudyPtr;
}

void DestructStudy() {
  delete GlobalStudyPtr;
  GlobalStudyPtr = NULL;
}
//******************************************************
//get and create the PVModel
//******************************************************
PVModel* studyRangeStudy::GetPVModel(bool expandTimeArrays) {
  if (ThePVModel!=NULL)
    delete ThePVModel;
  // create the PV model
  ThePVModel=new rewardPVModel(expandTimeArrays);
  return ThePVModel;
}


