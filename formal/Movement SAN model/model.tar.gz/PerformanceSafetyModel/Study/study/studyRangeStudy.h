
#ifndef studyRangeSTUDY_H_
#define studyRangeSTUDY_H_

#include "Reward/reward/rewardPVNodes.h"
#include "Reward/reward/rewardPVModel.h"
#include "Cpp/BaseClasses/GlobalVariables.h"
#include "Cpp/Study/BaseStudyClass.hpp"

extern Double MAnetDelay;
extern Double RBCprocessingTime;
extern Double TPRUpdatePeriod;
extern Double TPRnetDelay;
extern Double integrityNotConfirmedProb;
extern Int lineLength;
extern Short maxTrainSpeed;
extern Short nTrains;
extern Double netNotDeliveryProb;
extern Double positionUpdatePeriod;
extern Int safetyMargin;
extern Int trainLength;
extern Int trainScheduling;

class studyRangeStudy : public BaseStudyClass {
public:

studyRangeStudy();
~studyRangeStudy();

private:

double *MAnetDelayValues;
double *RBCprocessingTimeValues;
double *TPRUpdatePeriodValues;
double *TPRnetDelayValues;
double *integrityNotConfirmedProbValues;
int *lineLengthValues;
short *maxTrainSpeedValues;
short *nTrainsValues;
double *netNotDeliveryProbValues;
double *positionUpdatePeriodValues;
int *safetyMarginValues;
int *trainLengthValues;
int *trainSchedulingValues;

void SetValues_MAnetDelay();
void SetValues_RBCprocessingTime();
void SetValues_TPRUpdatePeriod();
void SetValues_TPRnetDelay();
void SetValues_integrityNotConfirmedProb();
void SetValues_lineLength();
void SetValues_maxTrainSpeed();
void SetValues_nTrains();
void SetValues_netNotDeliveryProb();
void SetValues_positionUpdatePeriod();
void SetValues_safetyMargin();
void SetValues_trainLength();
void SetValues_trainScheduling();

void PrintGlobalValues(int);
void *GetGVValue(char *TheGVName);
void OverrideGVValue(char *TheGVName, void *TheGVValue);
void SetGVs(int expnum);
PVModel *GetPVModel(bool expandTimeArrays);
};

#endif

