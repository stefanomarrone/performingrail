#ifndef modelRJ_H_
#define modelRJ_H_
#include <math.h>
#include "Cpp/Composer/Join.h"
#include "Cpp/Composer/AllStateVariableTypes.h"
#include "Composed/model/modelRJ__fleet.h"
#include "Atomic/trackside/tracksideSAN.h"

//State variable headers
#include "Cpp/BaseClasses/state/ArrayStateVariable.h"
#include "Cpp/BaseClasses/SAN/Place.h"
extern Short nTrains;

class modelRJ: public Join {
 public:
  modelRJ__fleet * fleet;
  tracksideSAN * trackside;
  maMsgOfTrains * MAmessages;
  Place * MAtoRBC;
  tprMsgArrayOfTrains * TPRmessages;
  Place * TPRtoRBC;

  modelRJ();
  ~modelRJ();
};

#endif
