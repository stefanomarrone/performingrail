#include "Composed/model/modelRJ.h"
char * modelRJ__SharedNames[] = {"MAmessages", "MAtoRBC", "TPRmessages", "TPRtoRBC"};

modelRJ::modelRJ():Join("join", 2, 4,modelRJ__SharedNames) {
  fleet = new modelRJ__fleet();
  ModelArray[0] = (BaseModelClass*) fleet;
  ModelArray[0]->DefineName("fleet");
  trackside = new tracksideSAN();
  ModelArray[1] = (BaseModelClass*) trackside;
  ModelArray[1]->DefineName("trackside");

  SetupActions();
  if (AllChildrenEmpty())
    NumSharedStateVariables = 0;
  else {
    //**************  State sharing info  **************
    //Shared variable 0
    MAmessages = new maMsgOfTrains("MAmessages");
    addSharedPtr(MAmessages, "MAmessages" );
    if (fleet->NumStateVariables > 0) {
      MAmessages->ShareWith(getSharableSVPointer(fleet->MAmessages));
      addSharingInfo(getSharableSVPointer(fleet->MAmessages), MAmessages, fleet);
    }
    if (trackside->NumStateVariables > 0) {
      MAmessages->ShareWith(getSharableSVPointer(trackside->MAmessages));
      addSharingInfo(getSharableSVPointer(trackside->MAmessages), MAmessages, trackside);
    }

    //Shared variable 1
    MAtoRBC = new Place("MAtoRBC");
    addSharedPtr(MAtoRBC, "MAtoRBC" );
    if (fleet->NumStateVariables > 0) {
      MAtoRBC->ShareWith(getSharableSVPointer(fleet->MAtoRBC));
      addSharingInfo(getSharableSVPointer(fleet->MAtoRBC), MAtoRBC, fleet);
    }
    if (trackside->NumStateVariables > 0) {
      MAtoRBC->ShareWith(getSharableSVPointer(trackside->MAtoRBC));
      addSharingInfo(getSharableSVPointer(trackside->MAtoRBC), MAtoRBC, trackside);
    }

    //Shared variable 2
    TPRmessages = new tprMsgArrayOfTrains("TPRmessages");
    addSharedPtr(TPRmessages, "TPRmessages" );
    if (fleet->NumStateVariables > 0) {
      TPRmessages->ShareWith(getSharableSVPointer(fleet->TPRmessages));
      addSharingInfo(getSharableSVPointer(fleet->TPRmessages), TPRmessages, fleet);
    }
    if (trackside->NumStateVariables > 0) {
      TPRmessages->ShareWith(getSharableSVPointer(trackside->TPRmessages));
      addSharingInfo(getSharableSVPointer(trackside->TPRmessages), TPRmessages, trackside);
    }

    //Shared variable 3
    TPRtoRBC = new Place("TPRtoRBC");
    addSharedPtr(TPRtoRBC, "TPRtoRBC" );
    if (fleet->NumStateVariables > 0) {
      TPRtoRBC->ShareWith(getSharableSVPointer(fleet->TPRtoRBC));
      addSharingInfo(getSharableSVPointer(fleet->TPRtoRBC), TPRtoRBC, fleet);
    }
    if (trackside->NumStateVariables > 0) {
      TPRtoRBC->ShareWith(getSharableSVPointer(trackside->TPRtoRBC));
      addSharingInfo(getSharableSVPointer(trackside->TPRtoRBC), TPRtoRBC, trackside);
    }

  }

  Setup();
}

modelRJ::~modelRJ() {
  if (!AllChildrenEmpty()) {
    delete MAmessages;
    delete MAtoRBC;
    delete TPRmessages;
    delete TPRtoRBC;
  }
  delete fleet;
  delete trackside;
}
