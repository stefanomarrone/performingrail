#ifndef modelRJ__fleet_H_
#define modelRJ__fleet_H_
#include <math.h>
#include "Cpp/Composer/Rep.h"
#include "Cpp/Composer/AllStateVariableTypes.h"

//Submodel header files
#include "Atomic/obuComm/obuCommSAN.h"

//State variable headers
#include "Cpp/BaseClasses/SAN/Place.h"
#include "Cpp/BaseClasses/state/ArrayStateVariable.h"
extern Short nTrains;

class modelRJ__fleet: public Rep {
 public:
  obuCommSAN ** InstanceArray;

  modelRJ__fleet();
  ~modelRJ__fleet();

  // Declare new variables
  Place * Count;
  maMsgOfTrains * MAmessages;
  Place * MAtoRBC;
  tprMsgArrayOfTrains * TPRmessages;
  Place * TPRtoRBC;
  shortArrayOfTrains * arrivalTime;
  intArrayOfTrains * trainHeadPositions;
  intArrayOfTrains * trainMAs;
  shortArrayOfTrains * trainSpeeds;
  intArrayOfTrains * trainTailPositions;
};

#endif
