#include "Composed/model/modelRJ__fleet.h"
char * modelRJ__fleet__SharedNames[] = {"Count", "MAmessages", "MAtoRBC", "TPRmessages", "TPRtoRBC", "arrivalTime", "trainHeadPositions", "trainMAs", "trainSpeeds", "trainTailPositions"};

modelRJ__fleet::modelRJ__fleet():Rep("fleet", nTrains, 10, modelRJ__fleet__SharedNames)
{
  InstanceArray = new obuCommSAN * [NumModels];
  delete[] ModelArray;
  ModelArray = (BaseModelClass **) InstanceArray;
  for (counter = 0; counter < NumModels; counter++)
    InstanceArray[counter] = new obuCommSAN();

  SetupActions();
  if (NumModels == 0) return;

  if (AllChildrenEmpty())
    NumSharedStateVariables = 0;
  else {
    //**************** Initialize local variables ****************
    Count = new Place("Count");
    addSharedPtr(Count, "Count");
    Count->ShareWith(InstanceArray[0]->Count);

    MAmessages = new maMsgOfTrains("MAmessages");
    addSharedPtr(MAmessages, "MAmessages");
    MAmessages->ShareWith(InstanceArray[0]->MAmessages);

    MAtoRBC = new Place("MAtoRBC");
    addSharedPtr(MAtoRBC, "MAtoRBC");
    MAtoRBC->ShareWith(InstanceArray[0]->MAtoRBC);

    TPRmessages = new tprMsgArrayOfTrains("TPRmessages");
    addSharedPtr(TPRmessages, "TPRmessages");
    TPRmessages->ShareWith(InstanceArray[0]->TPRmessages);

    TPRtoRBC = new Place("TPRtoRBC");
    addSharedPtr(TPRtoRBC, "TPRtoRBC");
    TPRtoRBC->ShareWith(InstanceArray[0]->TPRtoRBC);

    arrivalTime = new shortArrayOfTrains("arrivalTime");
    addSharedPtr(arrivalTime, "arrivalTime");
    arrivalTime->ShareWith(InstanceArray[0]->arrivalTime);

    trainHeadPositions = new intArrayOfTrains("trainHeadPositions");
    addSharedPtr(trainHeadPositions, "trainHeadPositions");
    trainHeadPositions->ShareWith(InstanceArray[0]->trainHeadPositions);

    trainMAs = new intArrayOfTrains("trainMAs");
    addSharedPtr(trainMAs, "trainMAs");
    trainMAs->ShareWith(InstanceArray[0]->trainMAs);

    trainSpeeds = new shortArrayOfTrains("trainSpeeds");
    addSharedPtr(trainSpeeds, "trainSpeeds");
    trainSpeeds->ShareWith(InstanceArray[0]->trainSpeeds);

    trainTailPositions = new intArrayOfTrains("trainTailPositions");
    addSharedPtr(trainTailPositions, "trainTailPositions");
    trainTailPositions->ShareWith(InstanceArray[0]->trainTailPositions);


    //Share state in submodels
    for (counter = 0; counter < NumModels; counter++) {
      addSharingInfo(InstanceArray[counter]->Count, Count);
    }
    for (counter = 0; counter < NumModels; counter++) {
      addSharingInfo(InstanceArray[counter]->MAmessages, MAmessages);
    }
    for (counter = 0; counter < NumModels; counter++) {
      addSharingInfo(InstanceArray[counter]->MAtoRBC, MAtoRBC);
    }
    for (counter = 0; counter < NumModels; counter++) {
      addSharingInfo(InstanceArray[counter]->TPRmessages, TPRmessages);
    }
    for (counter = 0; counter < NumModels; counter++) {
      addSharingInfo(InstanceArray[counter]->TPRtoRBC, TPRtoRBC);
    }
    for (counter = 0; counter < NumModels; counter++) {
      addSharingInfo(InstanceArray[counter]->arrivalTime, arrivalTime);
    }
    for (counter = 0; counter < NumModels; counter++) {
      addSharingInfo(InstanceArray[counter]->trainHeadPositions, trainHeadPositions);
    }
    for (counter = 0; counter < NumModels; counter++) {
      addSharingInfo(InstanceArray[counter]->trainMAs, trainMAs);
    }
    for (counter = 0; counter < NumModels; counter++) {
      addSharingInfo(InstanceArray[counter]->trainSpeeds, trainSpeeds);
    }
    for (counter = 0; counter < NumModels; counter++) {
      addSharingInfo(InstanceArray[counter]->trainTailPositions, trainTailPositions);
    }
    for (counter = 1; counter < NumModels; counter++) {
      InstanceArray[0]->Count->ShareWith(InstanceArray[counter]->Count);
      InstanceArray[0]->MAmessages->ShareWith(InstanceArray[counter]->MAmessages);
      InstanceArray[0]->MAtoRBC->ShareWith(InstanceArray[counter]->MAtoRBC);
      InstanceArray[0]->TPRmessages->ShareWith(InstanceArray[counter]->TPRmessages);
      InstanceArray[0]->TPRtoRBC->ShareWith(InstanceArray[counter]->TPRtoRBC);
      InstanceArray[0]->arrivalTime->ShareWith(InstanceArray[counter]->arrivalTime);
      InstanceArray[0]->trainHeadPositions->ShareWith(InstanceArray[counter]->trainHeadPositions);
      InstanceArray[0]->trainMAs->ShareWith(InstanceArray[counter]->trainMAs);
      InstanceArray[0]->trainSpeeds->ShareWith(InstanceArray[counter]->trainSpeeds);
      InstanceArray[0]->trainTailPositions->ShareWith(InstanceArray[counter]->trainTailPositions);
    }
  }
  Setup("obuComm");
}

modelRJ__fleet::~modelRJ__fleet() {
  if (NumModels == 0) return;
  delete Count;
  delete MAmessages;
  delete MAtoRBC;
  delete TPRmessages;
  delete TPRtoRBC;
  delete arrivalTime;
  delete trainHeadPositions;
  delete trainMAs;
  delete trainSpeeds;
  delete trainTailPositions;
  for (int i = 0; i < NumModels; i++)
    delete InstanceArray[i];
}

