#ifndef _REWARD_PVS_
#define _REWARD_PVS_
#include <math.h>
#include "Cpp/Performance_Variables/PerformanceVariableNode.hpp"
#include "Composed/model/modelRJ__fleet.h"
#include "Composed/model/modelRJ.h"
#include "Cpp/Performance_Variables/IntervalOfTime.hpp"
#include "Cpp/Performance_Variables/IntervalOfTimeImpulse.hpp"



class rewardPV0Impulse0:public IntervalOfTimeImpulse
{
 public:
  trainSAN *train;

  rewardPV0Impulse0();
  ~rewardPV0Impulse0();
  double Impulse_Function(double);
  ImpulseNodeClass** CreateImpulseWorkerList(int);
 private:
  ImpulseNodeClass** ImpulseWorkerList;
  int ImpulseWorkerListLength;
};

class rewardPV0:public PerformanceVariableNode
{
 public:
  modelRJ *ThemodelRJ;

  rewardPV0Impulse0 Impulse0;

  rewardPV0(int timeindex=0);
  ~rewardPV0();
  void CreateWorkerList(void);
};

#endif
