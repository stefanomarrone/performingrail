#include "rewardPVModel.h"

rewardPVModel::rewardPVModel(bool expandTimeArrays) {
  TheModel=new modelRJ();
  DefineName("rewardPVModel");
  StateMode = 1;
  CreatePVList(1, expandTimeArrays);
  Initialize();
}



PerformanceVariableNode* rewardPVModel::createPVNode(int pvindex, int timeindex) {
  switch(pvindex) {
  case 0:
    return new rewardPV0(timeindex);
    break;
  }
  return NULL;
}
