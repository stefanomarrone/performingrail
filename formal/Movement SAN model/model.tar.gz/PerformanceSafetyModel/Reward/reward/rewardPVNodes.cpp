#include "rewardPVNodes.h"

rewardPV0Impulse0::rewardPV0Impulse0()
{
  NumberOfModelDependencies = 1;
  TheModelPtr = new BaseModelClass**[NumberOfModelDependencies];
  TheModelPtr[0] = (BaseModelClass**)(&train);
  ImpulseWorkerListLength = 0;
}

rewardPV0Impulse0::~rewardPV0Impulse0() {
  delete [] TheModelPtr;
  if (ImpulseWorkerListLength > 0) {
    for (int ImpulseWorkerCounter = 0; ImpulseWorkerCounter < ImpulseWorkerListLength; ImpulseWorkerCounter++)
      delete ImpulseWorkerList[ImpulseWorkerCounter];
    delete[] ImpulseWorkerList;
  }
}

double rewardPV0Impulse0::Impulse_Function(double FiringTime)
{
return 1.0;

return(0);
}

ImpulseNodeClass** rewardPV0Impulse0::CreateImpulseWorkerList(int NumberOfWorkers) {
  ImpulseWorkerListLength = NumberOfWorkers;
  ImpulseWorkerList = new ImpulseNodeClass*[NumberOfWorkers];

  for (int ImpulseWorkerCounter = 0; ImpulseWorkerCounter < NumberOfWorkers; ImpulseWorkerCounter++)
  {
    ImpulseWorkerList[ImpulseWorkerCounter] = new rewardPV0Impulse0;
  }

  return ImpulseWorkerList;
}

rewardPV0::rewardPV0(int timeindex) {
  TheModelPtr = (BaseModelClass**)(&ThemodelRJ);
  double startpts[13]={0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
  double stoppts[13]={100.0, 150.0, 200.0, 250.0, 300.0, 350.0, 400.0, 450.0, 500.0, 550.0, 600.0, 650.0, 700.0};
  Initialize("numberOfTrains",(RewardType)1,13, startpts, stoppts, timeindex, 1,0, 0);
  AddImpulse("trainExits","train",&Impulse0);
}

rewardPV0::~rewardPV0() {
  for(int i = 0; i < NumberOfWorkers; i++) {
    delete[] WorkerList[i]->Name;
    delete WorkerList[i];
  }
}

void rewardPV0::CreateWorkerList(void) {
}
